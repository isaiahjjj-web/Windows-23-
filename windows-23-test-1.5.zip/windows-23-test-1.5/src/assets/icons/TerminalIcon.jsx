export default function TerminalIcon({ size = 24 }) {
  return <span style={{ fontSize: size }}>💻</span>;
}
