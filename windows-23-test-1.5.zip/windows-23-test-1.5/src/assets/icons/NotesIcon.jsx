export default function NotesIcon({ size = 24 }) {
  return <span style={{ fontSize: size }}>📝</span>;
}
