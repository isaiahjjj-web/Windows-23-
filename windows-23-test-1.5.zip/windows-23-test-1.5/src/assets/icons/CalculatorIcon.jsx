export default function CalculatorIcon({ size = 24 }) {
  return <span style={{ fontSize: size }}>🧮</span>;
}
