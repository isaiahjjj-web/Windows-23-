export default function BrowserIcon({ size = 24 }) {
  return <span style={{ fontSize: size }}>🌐</span>;
}
